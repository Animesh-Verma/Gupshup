package com.aplofie.analytics;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class proglang {

    public static final String tableQuery ="CREATE TABLE `proglang` (\n" +
            "\t`pid`\tINTEGER PRIMARY KEY AUTOINCREMENT,\n" +
            "\t`roll`\tTEXT,\n" +
            "\t`languages`\tTEXT\n" +
            ");";

    public static final String tablename ="proglang";


    public static long insertData(SQLiteDatabase sqLiteDatabase, ContentValues contentValues)
    {
        return sqLiteDatabase.insert(tablename, null, contentValues);

    }

    public static Cursor fatchData(SQLiteDatabase sqLiteDatabase, String whereClouse){

        return sqLiteDatabase.query(tablename, null, whereClouse, null, null, null,null, null);


    }
}
