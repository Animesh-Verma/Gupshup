package com.aplofie.analytics;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity {
EditText editText;
TextView textreq,textshow,acadmicreq,textacad;
Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.editcompany);
textreq=findViewById(R.id.textrequire);
textshow=findViewById(R.id.textshowreq);
acadmicreq=findViewById(R.id.acadmicreq);
textacad=findViewById(R.id.textacad);
button=findViewById(R.id.button);


textreq.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        myalert();
    }
});
acadmicreq.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

    }
});


acadmicreq.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        acadreq();
    }
});


button.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(MainActivity.this,SkillActivity.class);
        startActivity(intent);
        finish();
    }
});
    }


    void myalert() {
        Dialog dialog;
        final String[] items = {"Aptitude", "GD", "Communication"};
        final ArrayList itemselected = new ArrayList();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Requirements");
        builder.setMultiChoiceItems(items, null, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                if (isChecked) {
                    itemselected.add(which);
                } else if (itemselected.contains(which)) {
                    itemselected.remove(Integer.valueOf(which));
                }


            }
        }).setPositiveButton("Done!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                //Your logic when OK button is clicked
                dialog.dismiss();
              String st="";
                for(int i=0;i<itemselected.size();i++)
                    textshow.setText(st=st+itemselected.get(i));

            }
        })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        dialog = builder.create();
        dialog.show();






        }


    void acadreq() {
        Dialog dialog;
        final String[] items = {"Above 80%","Above 70%","Above 60%", "NoBacks","Doesn't matter"};
        final ArrayList itemselected = new ArrayList();
        final ArrayList arrayList =new ArrayList();
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);





        builder.setTitle("Academic");
        builder.setMultiChoiceItems(items, null, new DialogInterface.OnMultiChoiceClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                if (isChecked) {
                    itemselected.add(which);
                } else if (itemselected.contains(which)) {
                    itemselected.remove(Integer.valueOf(which));
                }


            }
        }).setPositiveButton("Done!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                //Your logic when OK button is clicked
                dialog.dismiss();
                String st="",con;
                for(int i=0;i<itemselected.size();i++) {
                    //textacad.setText(st = st + itemselected.get(i));
                arrayList.add(itemselected);
                }
                StringBuilder builder = new StringBuilder();
                for (String details : list2) {
                    builder.append(details + "\n");
                }

                custName.setText(builder.toString());

                if(st.contains("0"))
                    con="80";
                if(st.contains("1"))
                    con="70";
                if(st.contains("2"))
                    con="60";
                if(st.contains("3"))
                    con="0";

textacad.setText();

            }
        })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        dialog = builder.create();
        dialog.show();







    }





    }