package com.aplofie.analytics;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class question {

    public static final String tableQuery ="CREATE TABLE `question` (\n" +
            "\t`sid`\tINTEGER PRIMARY KEY AUTOINCREMENT,\n" +
            "\t`roll`\tTEXT,\n" +
            "\t`attend`\tTEXT,\n" +
            "\t`clg_mks`\tTEXT,\n" +
            "\t`lab_imp`\tTEXT,\n" +
            "\t`self_study`\tTEXT,\n" +
            "\t`coaching`\tTEXT,\n" +
            "\t`event`\tTEXT,\n" +
            "\t`project`\tTEXT,\n" +
            "\t`team`\tTEXT,\n" +
            "\t`gk`\tTEXT,\n" +
            "\t`certificate`\tTEXT,\n" +
            "\t`comm_class`\tTEXT\n" +
            ");";

    public static final String tablename ="question";


    public static long insertData(SQLiteDatabase sqLiteDatabase, ContentValues contentValues)
    {
        return sqLiteDatabase.insert(tablename, null, contentValues);

    }

    public static Cursor fatchData(SQLiteDatabase sqLiteDatabase, String whereClouse){

        return sqLiteDatabase.query(tablename, null, whereClouse, null, null, null,null, null);


    }
}
